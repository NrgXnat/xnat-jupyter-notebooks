import click
import xnat


@click.group(hidden=True)
@click.pass_context
def search(ctx):
    pass
