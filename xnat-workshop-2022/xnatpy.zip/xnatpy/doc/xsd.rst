Generated XSD classes
=====================

:mod:`XSD Classes` Documentation
--------------------------------

This is an overview of all generated classes based on the XSD files of central.xnat.org,
without any extension types (only the default XSD files that come with XNAT 1.7)

.. automodule:: xnat.classes
    :members:
    :undoc-members:
    :show-inheritance:
